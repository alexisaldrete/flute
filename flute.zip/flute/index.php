<!DOCTYPE html>
<html>
<head>
	<title>Flute Machining Home</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/index_styles.css">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<body>

	<!-- --------------------------    NAVBAR --------------------------------- -->
	<nav id=nav class="navbar navbar-default navbar-fixed-top" role = "navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target = "#navbar-collapse-main">

					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="#"><img id="logo" src="logos/ap3/White.png"></a>
			</div>
			<div class="collapse navbar-collapse" id="navbar-collapse-main">
				<ul class="nav navbar-nav">
					<li><a id=nb1 class="active" href="#">Inicio</a></li>
					<li><a id=nb2 class="opc" href="#">Nosotros</a></li>
					<li><a id=nb3 class="opc" href="#">Servicios</a></li>
					<li><a id=nb4 class="opc" href="#">Contacto</a></li>
					<li >
						<button type="button" id="btn_si" class="btn btn-default btn-sm">
			  				Sign In
						</button>	
					</li>
					<li>
						<button type="button" id="btn_comenzar" class="btn btn-default btn-sm">
			  				COMENZAR
						</button>	
					</li>
				</ul>
				
				
			</div>
		</div>	
	</nav>


<!-- --------------------------    PARTE 1    --------------------------------- -->
	<div id="home">
		<div class="row">
			<!-- landTcol1 Landing Text Columna 1 -->
			<div id=landTcol1 class="col-sm-5">
				<h1 class="white">BOOTSTRAP</h1>
				<p class="white">The incorporate instinct complains inside an orange geometry. The bandwagon relaxes underneath the mum. Why won't any convenience walk? The supreme institute waffles across the individual.<p>
				<p class="red"><span>&#9654</span><span class="white"> Aqui va mas texto</span></p>
					
				<button type="button" class="btn btn-default btn-md">
			  		COMENZAR AHORA
				</button>

			</div>

			<!-- landTcol2 Landing Text Columna 2 -->
			<div id=landTcol2 class="col-sm-7"></div>
		</div>

<!-- --------------------------    PARTE 2    --------------------------------- -->

	</div>

	<div class="padding">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-12">
					<img id="foto1" src="Images/lijadora.jpeg">
				</div>
				<div class="col-lg-6 col-md-12">
					<h2>Esto es un Titulo</h2>

					<p class="lead">The overall laugh paces. The jacket digests the problem. A dive executes our automobile in the generic damned. The tested abstract ropes the blessed.</p>

					<br>

					<p class="lead">The overall laugh paces. The jacket digests the problem. A dive executes our automobile in the generic damned. The tested abstract ropes the blessed.</p>

					<br>

					<p class="lead">The overall laugh paces. The jacket digests the problem. A dive executes our automobile in the generic damned. The tested abstract ropes the blessed.</p>

				</div>
			</div>
		</div>
	</div>

	<div class="padding">
		<div class="container">
			<div class="row">
				<div class="col-md-3 col-sm-6 col-xs-12">
					<h5>Built with Sass</h5>
					<p class="lead">The overall laugh paces. The jacket digests the problem. A dive executes our automobile in the generic damned. The tested abstract ropes the blessed.</p>
				</div>

				<div class="col-md-3 col-sm-6 col-xs-12">
					<h5>Built with Sass</h5>
					<p class="lead">The overall laugh paces. The jacket digests the problem. A dive executes our automobile in the generic damned. The tested abstract ropes the blessed.</p>
				</div>

				<div class="col-md-3 col-sm-6 col-xs-12">
					<h5>Built with Sass</h5>
					<p class="lead">The overall laugh paces. The jacket digests the problem. A dive executes our automobile in the generic damned. The tested abstract ropes the blessed.</p>
				</div>

				<div class="col-md-3 col-sm-6 col-xs-12">
					<h5>Built with Sass</h5>
					<p class="lead">The overall laugh paces. The jacket digests the problem. A dive executes our automobile in the generic damned. The tested abstract ropes the blessed.</p>
				</div>
			</div>
		</div>
	</div>

	<div id="fixed">
		
	</div>

	<div class="padding">
		<div class="container">
			<div class="row">

				<div class="col-xs-6">
					<h2>Esto es un Titulo</h2>

					<p class="lead">The overall laugh paces. The jacket digests the problem. A dive executes our automobile in the generic damned. The tested abstract ropes the blessed.</p>

					<br>

					<p class="lead">The overall laugh paces. The jacket digests the problem. A dive executes our automobile in the generic damned. The tested abstract ropes the blessed.</p>

					<br>

					<p class="lead">The overall laugh paces. The jacket digests the problem. A dive executes our automobile in the generic damned. The tested abstract ropes the blessed.</p>

				</div>

				<div class="col-xs-6">
					<img id="foto1" src="Images/lijadora.jpeg">
				</div>
				
			</div>
		</div>
	</div>

	<footer class="container-fluid text-center">
		<div class="row">
			<div class="col-sm-4">

				<h3>Contact Us</h3>
				<br>
				<h4>Our address is bla bla bla</h4>
				
			</div>
			<div class="col-sm-4">

				<h3>Contact Us</h3>
				<a href="#" class="fa fa-facebook"></a>
				<a href="#" class="fa fa-twitter"></a>
				<a href="#" class="fa fa-google"></a>
				<a href="#" class="fa fa-linkedin"></a>
				<a href="#" class="fa fa-youtube"></a>
				
			</div>
			<div class="col-sm-4">

				<h3>Contact Us</h3>
				<br>
				<h4>Our address is bla bla bla</h4>
				
			</div>
		</div>
		
	</footer>
	

</body>
</html>