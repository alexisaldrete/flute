<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="css/index_styles2.css">

    <title>Hello, world!</title>
  </head>
  <body>

<!--------------------------------- NAVBAR --------------------------------->
    <nav class="navbar navbar-expand-xl navbar-light fixed-top">
      <a class="navbar-brand" href="#"><img id="logo" src="logos/ap3/White.png"></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
          <li class="nav-item active">
            <a class="white nav-link" href="#">Inicio <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="white nav-link" href="#">Nosotros</a>
          </li>
          <li class="nav-item">
            <a class="white nav-link" href="#">Contacto</a>
          </li>
          <li class="nav-item dropdown">
            <a class="white  nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Servicios
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <a class="dropdown-item" href="#">Servicio 1</a>
              <a class="dropdown-item" href="#">Servicio 2</a>
              <a class="dropdown-item" href="#">Servicio 3</a>
            </div>
          </li>
          <li>
            <div class="btn_cont">
              <button type="button" id="btn_si" class="btn btn-default btn-sm">
                Sign In
              </button> 

            <button type="button" id="btn_comenzar" class="btn btn-default btn-sm">
                COMENZAR
            </button> 

            </div>
          </li>
        </ul>
      </div>
    </nav>



      <!--------------------------------- PARTE 1 --------------------------------->
      
        
      
      <div class="parte1">
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
          </ol>
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img class="d-block w-100" src="Images/cortadora.jpeg" alt="First slide">
              <div class="carousel-caption d-none d-md-block">
                <h5>FOTO 1</h5>
                <p>ESTA ES FOTO 1</p>
              </div>
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="Images/cortadora2.jpeg" alt="Second slide">
              <div class="carousel-caption d-none d-md-block">
                <h5>FOTO 2</h5>
                <p>ESTA ES FOTO 2</p>
              </div>
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="Images/lijadora.jpeg" alt="Third slide">
              <div class="carousel-caption d-none d-md-block">
                <h5>FOTO 3</h5>
                <p>ESTA ES FOTO 3</p>
              </div>
            </div>
          </div>
          <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
      </div>

      <!--------------------------------- PARTE 2 --------------------------------->

      <div class="parte2">
        <div class="col-container">
          <div class="row">
            <div id="col1" class="col-xl-5 col-lg-12">

              <div id="rectangulo">  

              </div>
              <p id=p1><span  class="texto1">CAL</span><span class="texto2">IDAD</span></p>
              <p id=p2 ><span class="texto1">PRE</span><span class="texto2">CISIÓN</span></p>
              <p id=p3><span  class="texto1">EFI</span><span class="texto2">CACIA</span></p>
            </div>

            <div id="col2" class="col-xl-7 col-lg-12">

              <p class="lead">The overall laugh paces. The jacket digests the problem. A dive executes our automobile in the generic damned. The tested abstract ropes the blessed vefced vefc edv fe cd ef vef b gevfc dwx cefvg ec w frv betvce ev vecxdw.</p>
              <br>
              <p class="indent"><span class="red">&#9654</span>Aqui es una linea de texto.</p>
              <p class="indent"><span class="red">&#9654</span>Aqui es uncdscscsda linea de tedsdcvsdxto.</p>
              <p class="indent"><span class="red">&#9654</span>Aqucsdcsi cses unacsdc linea de texto.</p>
              <p class="indent"><span class="red">&#9654</span>Aqui cscscsvges vecuna linea de texceeto.</p>
              <br>
              <button type="button" class="btn">LEARN MORE</button>

              
            </div>
          </div>
        </div>

      </div>

      <!--------------------------------- PARTE 3 --------------------------------->
      
      <div class="parte3">
        <h1>LOREM IPSUM <br>
        DOLOR SIT AMET</h1>
        <button type="button" class="btn" style="float: right;">COMENZAR AHORA</button>
      </div>

       <!--------------------------------- PARTE 4 --------------------------------->
      
      <div class="parte4">
        <div class="container">
           <h1>HOW DOES IT WORK</h1>
           <br>
            <p class="lead">The overall laugh paces. The jacket digests the problem. A dive executes our automobile in the generic damned. The tested abstract ropes the blessed vefced vefc edv fe cd ef vef b gevfc dwx cefvg ec w frv betvce ev vecxdw.</p>
        </div>
      </div>

      <!---------------------------------- PARTE 5 --------------------------------->
      
      <div class="parte5">
        
         

      </div>



    <!--------------------------------- SCRIPTS ----------------------------------->
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>